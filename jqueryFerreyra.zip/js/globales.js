const camisetas = [];

let carrito = [];

