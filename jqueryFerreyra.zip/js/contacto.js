class Contacto {
    constructor(nombre, apellido, telefono, email, comentario) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.telefono = telefono;
        this.email = email;
        this.comentario = comentario;
    }
}

