// METODO READY
$(document).ready(function () {
    console.log("Se cargó el DOM");
    
    //JQUERY Y SELECTORES
    const botones = $('.btn-compra');
    for (const boton of botones) {
    boton.onclick = comprarCamiseta;
    }

    //OBTENER INFO EN STORAGE
    if("CARRITO" in localStorage) {
        const datosGuardados = JSON.parse(localStorage.getItem("CARRITO"));
        for (const literal of datosGuardados) {
            carrito.push(new Camiseta(literal.id, literal.modelo, literal.nombre,literal.precio));
        }
        //SALIDA
        carritoUI(carrito);
    }
    $(".dropdown-menu").click(function(e) {
        e.stopPropagation();
    });
});
window.addEventListener("load", ()=> {
    $("#indicadorCarga").remove();
});
//INSTANCIAR OBJETOS Y ASOCIAR AL ARRAY GLOBAL
camisetas.push(new Camiseta('imgCamisetas/atlanta11.jpg', "Youth Atlanta", "Hawks Trae Young", "Nike Red 2019/20 Swingman Jersey", 1.888, 1));
camisetas.push(new Camiseta('imgCamisetas/celticsBird.webp', "Boston Celtics", "Larry Bird Mitchell & Ness Kelly", "Green Hardwood Classics", 1.999, 2));
camisetas.push(new Camiseta('imgCamisetas/bulls24.jpg', "Youth Chicago Bulls", "Lauri Markkanen", "Nike Red Swingman Jersey - Icon Edition", 1.788, 3)); 
camisetas.push(new Camiseta('imgCamisetas/lakers23.webp', "Los Angeles Lakers", "LeBron James", "Nike Gold 2020/21 Swingman Jersey", 1.999, 4));
camisetas.push(new Camiseta('imgCamisetas/lakersNegra.webp', "Los Angeles Lakers", "LeBron James", "Nike Black City Edition Swingman Jersey", 2.333, 5));
camisetas.push(new Camiseta('imgCamisetas/milwaukeeAllen.webp',"Milwaukee Bucks", "Allen Mitchell", "Black Hardwood Classics Swingman Jersey", 2.899, 6));

console.log(camisetas);

//GENERO INTERFAZ DE CAMISETAS
camisetaJquery(camisetas, '#productoCamiseta');
